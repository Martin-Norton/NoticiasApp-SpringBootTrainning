package com.mnort.noticia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoticiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoticiaApplication.class, args);
	}

}
